# Image assets

This folder is ready for SONIQ product photography. The current hero headphone illustration is drawn as inline SVG in `index.html`, so the page has no external image dependency.
