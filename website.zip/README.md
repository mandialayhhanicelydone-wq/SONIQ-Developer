# SONIQ static website

A responsive product website for SONIQ wireless over-ear headphones. Built with HTML5 and CSS3; it has no JavaScript, framework, package manager, or build step.

## Files

- `index.html` — semantic page structure, product copy, contact details, metadata, and UI-only enquiry form
- `style.css` — responsive layout, design tokens, focus states, and reduced-motion support
- `assets/images/soniq-headphones-hero.png` — original SONIQ product visual
- `assets/soniq-mark.svg` — favicon / sound-wave mark

## Run locally

Open `index.html` in a browser. All local asset paths are relative to the project root.

## Deploy to Vercel

Import the folder or upload its contents as a static project. No build command, output directory, environment variables, `package.json`, or `vercel.json` are needed; Vercel serves `index.html` directly.

The contact form is a visual front-end only and does not send or store submissions. Contact SONIQ directly at [SONIQ@gmail.com](mailto:SONIQ@gmail.com). The social links are placeholder destinations. The testimonial cards are explicitly marked as placeholders and should be replaced with verified customer reviews before launch.

## Edit the site

Change the content in `index.html` and adjust colors, typography, spacing, or breakpoints in the `:root` section and media queries in `style.css`. Google Fonts load over the network when available; system sans-serif fallbacks are included.
