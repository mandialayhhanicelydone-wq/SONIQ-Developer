# SONIQ static website

A responsive, single-page product website for SONIQ wireless headphones. It uses semantic HTML and a separate stylesheet; no JavaScript, framework, package manager, environment variables, or build step is required.

## Preview locally

Open `index.html` in a browser. All site files use relative paths. The page works without a local server.

## Deploy to Vercel

1. Extract `website.zip` so `index.html` is at the repository root.
2. Push the extracted files to a Git repository and import it into Vercel, or upload the project through your preferred Vercel workflow.
3. Select **Other** as the framework preset if prompted. Leave the build command empty and set the output directory to `.`.

No `vercel.json` is needed for this static site; Vercel serves `index.html` and its relative assets directly.

## Before publishing

- Replace the example email and phone placeholders with your business contact details.
- Replace the clearly marked testimonial placeholder when verified customer feedback is available.
- Add real social profile URLs in the footer.
- The contact form is intentionally a front-end UI only. It does not submit or store messages. Connect a form service or backend to receive inquiries.
- The product descriptions communicate the provided product range and features. Confirm final model specifications before making model-specific claims.

## Files

- `index.html` — accessible page structure, copy, navigation, form, and metadata
- `style.css` — responsive visual system and component styles
- `assets/images/` — reserved folder for future product photography
